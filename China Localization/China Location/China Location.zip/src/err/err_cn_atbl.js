/**
 * Copyright © 2018, Oracle and/or its affiliates. All rights reserved.
 * @NApiVersion 2.0
 * @NModuleScope Public
 */
define([],

function() {
    return {
        RUN_REPORT_ERROR: 'RunReportError',
        REPORT_ROWS_EXCEED_THRESHOLD: 'ReportRowsExceedThreshold'
    }
});