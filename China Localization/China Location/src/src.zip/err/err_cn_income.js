/**
 * Copyright © 2017, Oracle and/or its affiliates. All rights reserved.
 * @NApiVersion 2.0
 * @NModuleScope Public
 */
define([],

function() {
    return {
        RUN_REPORT_ERROR: 'RunReportError',
        REPORT_COLUMN_UNEXPECTED: 'ReportColumnsUnExpected'
    }
});
